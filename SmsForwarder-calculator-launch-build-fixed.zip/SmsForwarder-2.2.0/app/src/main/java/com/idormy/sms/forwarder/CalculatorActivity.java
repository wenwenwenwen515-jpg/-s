package com.idormy.sms.forwarder;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CalculatorActivity extends AppCompatActivity {
    private TextView display;
    private String expression = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLayout();
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(16));
        root.setBackgroundColor(Color.rgb(235, 248, 235));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("计算器");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(40, 80, 40));
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button skip = new Button(this);
        skip.setText("跳过");
        skip.setAllCaps(false);
        skip.setTextSize(16);
        skip.setOnClickListener(v -> enterApp());
        top.addView(skip, new LinearLayout.LayoutParams(dp(86), dp(48)));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(56)));

        display = new TextView(this);
        display.setText("0");
        display.setTextSize(34);
        display.setTextColor(Color.BLACK);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setPadding(dp(10), 0, dp(10), 0);
        display.setSingleLine(true);
        root.addView(display, new LinearLayout.LayoutParams(-1, dp(88)));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        String[] keys = new String[]{
                "C", "⌫", "÷", "×",
                "7", "8", "9", "-",
                "4", "5", "6", "+",
                "1", "2", "3", "=",
                "0", "00", ".", "="
        };
        for (String key : keys) {
            Button b = new Button(this);
            b.setText(key);
            b.setTextSize(22);
            b.setAllCaps(false);
            b.setOnClickListener(v -> onKey(((Button) v).getText().toString()));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = dp(72);
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(b, lp);
        }
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void enterApp() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void onKey(String key) {
        if ("C".equals(key)) {
            expression = "";
            updateDisplay();
            return;
        }
        if ("⌫".equals(key)) {
            if (expression.length() > 0) expression = expression.substring(0, expression.length() - 1);
            updateDisplay();
            return;
        }
        if ("=".equals(key)) {
            try {
                expression = calculate(expression);
            } catch (Exception e) {
                Toast.makeText(this, "计算错误", Toast.LENGTH_SHORT).show();
            }
            updateDisplay();
            return;
        }
        if ("×".equals(key)) key = "*";
        if ("÷".equals(key)) key = "/";
        expression += key;
        updateDisplay();
    }

    private void updateDisplay() {
        display.setText(expression.length() == 0 ? "0" : expression.replace("*", "×").replace("/", "÷"));
    }

    private String calculate(String exp) {
        if (exp == null || exp.trim().isEmpty()) return "0";
        List<String> tokens = tokenize(exp);
        List<String> rpn = toRpn(tokens);
        BigDecimal result = evalRpn(rpn);
        result = result.stripTrailingZeros();
        return result.toPlainString();
    }

    private List<String> tokenize(String s) {
        List<String> list = new ArrayList<>();
        StringBuilder num = new StringBuilder();
        char prev = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                num.append(c);
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                if (c == '-' && (i == 0 || prev == '+' || prev == '-' || prev == '*' || prev == '/')) {
                    num.append(c);
                } else {
                    if (num.length() > 0) { list.add(num.toString()); num.setLength(0); }
                    list.add(String.valueOf(c));
                }
            }
            if (!Character.isWhitespace(c)) prev = c;
        }
        if (num.length() > 0) list.add(num.toString());
        return list;
    }

    private int precedence(String op) {
        if ("+".equals(op) || "-".equals(op)) return 1;
        if ("*".equals(op) || "/".equals(op)) return 2;
        return 0;
    }

    private List<String> toRpn(List<String> tokens) {
        List<String> out = new ArrayList<>();
        Stack<String> ops = new Stack<>();
        for (String t : tokens) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                while (!ops.empty() && precedence(ops.peek()) >= precedence(t)) out.add(ops.pop());
                ops.push(t);
            } else {
                out.add(t);
            }
        }
        while (!ops.empty()) out.add(ops.pop());
        return out;
    }

    private BigDecimal evalRpn(List<String> rpn) {
        Stack<BigDecimal> stack = new Stack<>();
        for (String t : rpn) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                BigDecimal b = stack.pop();
                BigDecimal a = stack.pop();
                if ("+".equals(t)) stack.push(a.add(b));
                else if ("-".equals(t)) stack.push(a.subtract(b));
                else if ("*".equals(t)) stack.push(a.multiply(b));
                else stack.push(a.divide(b, 10, RoundingMode.HALF_UP));
            } else {
                stack.push(new BigDecimal(t));
            }
        }
        return stack.empty() ? BigDecimal.ZERO : stack.pop();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
