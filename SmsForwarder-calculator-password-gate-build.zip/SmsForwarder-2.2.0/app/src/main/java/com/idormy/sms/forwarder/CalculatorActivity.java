package com.idormy.sms.forwarder;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CalculatorActivity extends AppCompatActivity {
    private TextView display;
    private String expression = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        buildLayout();
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#000000"));
        root.setPadding(dp(8), dp(8), dp(8), dp(10));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(0, dp(4), 0, dp(4));

        Space space = new Space(this);
        topBar.addView(space, new LinearLayout.LayoutParams(0, dp(40), 1f));

        Button close = buildTopButton("×");
        close.setOnClickListener(v -> enterApp());
        topBar.addView(close, new LinearLayout.LayoutParams(dp(40), dp(40)));
        root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(46);
        display.setTypeface(Typeface.DEFAULT_BOLD);
        display.setGravity(Gravity.END | Gravity.BOTTOM);
        display.setPadding(dp(12), dp(24), dp(12), dp(18));
        display.setSingleLine(true);
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        LinearLayout keypad = new LinearLayout(this);
        keypad.setOrientation(LinearLayout.VERTICAL);
        keypad.setPadding(0, 0, 0, dp(6));

        keypad.addView(buildRow(
                buildCalcButton("AC", "fn"),
                buildCalcButton("±", "fn"),
                buildCalcButton("%", "fn"),
                buildCalcButton("÷", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("7", "num"),
                buildCalcButton("8", "num"),
                buildCalcButton("9", "num"),
                buildCalcButton("×", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("4", "num"),
                buildCalcButton("5", "num"),
                buildCalcButton("6", "num"),
                buildCalcButton("-", "op")
        ));
        keypad.addView(buildRow(
                buildCalcButton("1", "num"),
                buildCalcButton("2", "num"),
                buildCalcButton("3", "num"),
                buildCalcButton("+", "op")
        ));
        keypad.addView(buildLastRow());

        root.addView(keypad, new LinearLayout.LayoutParams(-1, 0, 2.1f));
        setContentView(root);
    }

    private Button buildTopButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#2B2B2B"));
        bg.setCornerRadius(dp(20));
        b.setBackground(bg);
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private LinearLayout buildRow(Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(4f);
        row.setPadding(0, dp(4), 0, dp(4));
        for (Button b : buttons) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(74), 1f);
            lp.setMargins(dp(6), 0, dp(6), 0);
            row.addView(b, lp);
        }
        return row;
    }

    private LinearLayout buildLastRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setWeightSum(4f);
        row.setPadding(0, dp(4), 0, dp(4));

        Button zero = buildCalcButton("0", "num");
        zero.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        zero.setPadding(dp(28), 0, 0, 0);
        LinearLayout.LayoutParams zeroLp = new LinearLayout.LayoutParams(0, dp(74), 2f);
        zeroLp.setMargins(dp(6), 0, dp(6), 0);
        row.addView(zero, zeroLp);

        Button dot = buildCalcButton(".", "num");
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(0, dp(74), 1f);
        dotLp.setMargins(dp(6), 0, dp(6), 0);
        row.addView(dot, dotLp);

        Button eq = buildCalcButton("=", "op");
        LinearLayout.LayoutParams eqLp = new LinearLayout.LayoutParams(0, dp(74), 1f);
        eqLp.setMargins(dp(6), 0, dp(6), 0);
        row.addView(eq, eqLp);

        return row;
    }

    private Button buildCalcButton(String text, String type) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(28);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setTextColor(Color.WHITE);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(37));
        if ("op".equals(type)) {
            bg.setColor(Color.parseColor("#FF9F0A"));
            b.setTextColor(Color.WHITE);
        } else if ("fn".equals(type)) {
            bg.setColor(Color.parseColor("#A5A5A5"));
            b.setTextColor(Color.BLACK);
        } else {
            bg.setColor(Color.parseColor("#333333"));
            b.setTextColor(Color.WHITE);
        }
        b.setBackground(bg);
        b.setOnClickListener(v -> onKey(((Button) v).getText().toString()));
        return b;
    }

    private void enterApp() {
        startActivity(new Intent(this, PasswordActivity.class));
        finish();
    }

    private void onKey(String key) {
        if ("AC".equals(key)) {
            expression = "";
            updateDisplay();
            return;
        }
        if ("±".equals(key)) {
            expression = toggleCurrentNumberSign(expression);
            updateDisplay();
            return;
        }
        if ("%".equals(key)) {
            expression = percentCurrentNumber(expression);
            updateDisplay();
            return;
        }
        if ("=".equals(key)) {
            try {
                expression = calculate(expression);
            } catch (Exception e) {
                Toast.makeText(this, "计算错误", Toast.LENGTH_SHORT).show();
            }
            updateDisplay();
            return;
        }
        if ("×".equals(key)) key = "*";
        if ("÷".equals(key)) key = "/";
        expression += key;
        updateDisplay();
    }

    private void updateDisplay() {
        display.setText(expression.length() == 0 ? "0" : expression.replace("*", "×").replace("/", "÷"));
    }

    private String toggleCurrentNumberSign(String exp) {
        if (exp == null || exp.isEmpty()) return "-";
        int i = exp.length() - 1;
        while (i >= 0) {
            char c = exp.charAt(i);
            if (c == '+' || c == '*' || c == '/') break;
            if (c == '-') {
                if (i == 0 || "+-*/".indexOf(exp.charAt(i - 1)) >= 0) break;
                break;
            }
            i--;
        }
        int start = i + 1;
        String prefix = exp.substring(0, start);
        String number = exp.substring(start);
        if (number.startsWith("-")) number = number.substring(1);
        else number = "-" + number;
        return prefix + number;
    }

    private String percentCurrentNumber(String exp) {
        if (exp == null || exp.isEmpty()) return exp;
        int i = exp.length() - 1;
        while (i >= 0) {
            char c = exp.charAt(i);
            if (c == '+' || c == '*' || c == '/') break;
            if (c == '-') {
                if (i == 0 || "+-*/".indexOf(exp.charAt(i - 1)) >= 0) break;
                break;
            }
            i--;
        }
        int start = i + 1;
        String prefix = exp.substring(0, start);
        String number = exp.substring(start);
        if (number.equals("-") || number.isEmpty()) return exp;
        BigDecimal n = new BigDecimal(number);
        n = n.divide(new BigDecimal("100"), 10, RoundingMode.HALF_UP).stripTrailingZeros();
        return prefix + n.toPlainString();
    }

    private String calculate(String exp) {
        if (exp == null || exp.trim().isEmpty()) return "0";
        List<String> tokens = tokenize(exp);
        List<String> rpn = toRpn(tokens);
        BigDecimal result = evalRpn(rpn);
        result = result.stripTrailingZeros();
        return result.toPlainString();
    }

    private List<String> tokenize(String s) {
        List<String> list = new ArrayList<>();
        StringBuilder num = new StringBuilder();
        char prev = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                num.append(c);
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                if (c == '-' && (i == 0 || prev == '+' || prev == '-' || prev == '*' || prev == '/')) {
                    num.append(c);
                } else {
                    if (num.length() > 0) {
                        list.add(num.toString());
                        num.setLength(0);
                    }
                    list.add(String.valueOf(c));
                }
            }
            if (!Character.isWhitespace(c)) prev = c;
        }
        if (num.length() > 0) list.add(num.toString());
        return list;
    }

    private int precedence(String op) {
        if ("+".equals(op) || "-".equals(op)) return 1;
        if ("*".equals(op) || "/".equals(op)) return 2;
        return 0;
    }

    private List<String> toRpn(List<String> tokens) {
        List<String> out = new ArrayList<>();
        Stack<String> ops = new Stack<>();
        for (String t : tokens) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                while (!ops.empty() && precedence(ops.peek()) >= precedence(t)) out.add(ops.pop());
                ops.push(t);
            } else {
                out.add(t);
            }
        }
        while (!ops.empty()) out.add(ops.pop());
        return out;
    }

    private BigDecimal evalRpn(List<String> rpn) {
        Stack<BigDecimal> stack = new Stack<>();
        for (String t : rpn) {
            if ("+".equals(t) || "-".equals(t) || "*".equals(t) || "/".equals(t)) {
                BigDecimal b = stack.pop();
                BigDecimal a = stack.pop();
                if ("+".equals(t)) stack.push(a.add(b));
                else if ("-".equals(t)) stack.push(a.subtract(b));
                else if ("*".equals(t)) stack.push(a.multiply(b));
                else stack.push(a.divide(b, 10, RoundingMode.HALF_UP));
            } else {
                stack.push(new BigDecimal(t));
            }
        }
        return stack.empty() ? BigDecimal.ZERO : stack.pop();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
