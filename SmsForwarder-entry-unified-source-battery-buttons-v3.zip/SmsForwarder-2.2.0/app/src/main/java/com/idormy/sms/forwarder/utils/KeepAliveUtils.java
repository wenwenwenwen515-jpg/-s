package com.idormy.sms.forwarder.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.provider.Telephony;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.idormy.sms.forwarder.R;

public class KeepAliveUtils {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean isIgnoreBatteryOptimization(Activity activity) {
        PowerManager powerManager = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            return powerManager.isIgnoringBatteryOptimizations(activity.getPackageName());
        } else {
            return true;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void ignoreBatteryOptimization(Activity activity) {
        if (isIgnoreBatteryOptimization(activity)) {
            openAppBatterySetting(activity);
            return;
        }
        @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + activity.getPackageName()));
        ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo != null) {
            activity.startActivity(intent);
        } else {
            openAppBatterySetting(activity);
        }
    }

    /**
     * 打开手机系统电池/省电/后台电量相关页面。
     * 按你的要求：优先跳手机设置里的电池功能，不优先跳应用详情。
     */
    public static void openAppBatterySetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();

        // 目标：优先进入“设置 -> 电池”首页，不优先进入省电模式/节电助手。
        Intent[] commonBatteryHome = new Intent[]{
                new Intent("android.settings.BATTERY_SETTINGS"),
                new Intent("android.intent.action.POWER_USAGE_SUMMARY"),
                new Intent("android.settings.POWER_USAGE_SUMMARY"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$PowerUsageSummaryActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.fuelgauge.PowerUsageSummary")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BatteryDashboardActivity"))
        };

        Intent[] oppoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerControlActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.power.PowerUsageSummaryActivity"))
        };

        Intent[] xiaomiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.BatteryHistoryDetailActivity"))
        };

        Intent[] vivoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.AbeMainActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.PowerUsageActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.MainActivity"))
        };

        Intent[] huaweiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerUsageActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.BatteryHistoryActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"))
        };

        Intent[] samsungBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        };

        // 按品牌优先尝试对应电池首页，再尝试通用电池首页。省电模式放最后，避免 vivo/小米/华为直接进省电模式。
        if (manufacturer.contains("oppo") || manufacturer.contains("oneplus") || manufacturer.contains("realme") || manufacturer.contains("oplus")) {
            if (startFirstAvailable(activity, oppoBattery, false)) return;
        } else if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            if (startFirstAvailable(activity, vivoBattery, false)) return;
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            if (startFirstAvailable(activity, xiaomiBattery, false)) return;
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            if (startFirstAvailable(activity, huaweiBattery, false)) return;
        } else if (manufacturer.contains("samsung")) {
            if (startFirstAvailable(activity, samsungBattery, false)) return;
        }

        if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        if (startFirstAvailable(activity, oppoBattery, false)) return;
        if (startFirstAvailable(activity, xiaomiBattery, false)) return;
        if (startFirstAvailable(activity, vivoBattery, false)) return;
        if (startFirstAvailable(activity, huaweiBattery, false)) return;
        if (startFirstAvailable(activity, samsungBattery, false)) return;

        Intent[] lastResort = new Intent[]{
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) : null,
                new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, lastResort, true);
    }

    /**
     * 尽量直接打开本应用权限管理页。
     * 厂商权限页不是 Android 统一公开接口，所以这里按常见系统多入口尝试。
     */
    public static void openAppPermissionSetting(Activity activity) {
        String pkg = activity.getPackageName();
        Intent[] intents = new Intent[]{
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.provider.extra.APP_PACKAGE", pkg)
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
                        .putExtra("packageName", pkg),
                new Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                        .setData(Uri.parse("package:" + pkg))
                        .putExtra("android.intent.extra.SHOW_FRAGMENT", "com.android.settings.applications.AppPermissionSettings"),

                // Xiaomi / MIUI / HyperOS
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg)
                        .putExtra("extra_package_uid", activity.getApplicationInfo().uid),

                // OPPO / OnePlus / ColorOS / OPlus
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.securitypermission", "com.oplus.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.safeguard.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.SingleAppActivity"))
                        .putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg),

                // Samsung
                new Intent().setComponent(new ComponentName("com.samsung.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg),
                new Intent().setComponent(new ComponentName("com.google.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 尽量打开厂商自启动设置页；不行再跳系统设置；系统设置也打不开就不处理。
     * 按你的要求：不跳应用详情页。
     */
    public static void openAutoStartSetting(Activity activity) {
        Intent[] intents = new Intent[]{
                // OPPO / OnePlus / Realme / ColorOS / OPlus
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity")),

                // Xiaomi / MIUI / HyperOS
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartDetailManagementActivity")),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.SoftwareManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),

                // Meizu / Letv / Asus / Samsung
                new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity")),
                new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
                new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).putExtra("mobilemanager://function/entry/AutoStart", true),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity")),

                // 如果直达自启动失败，OPPO/华为/荣耀至少跳到“设置 -> 应用/应用和服务”附近，比设置首页更近。
                new Intent(Settings.ACTION_APPLICATION_SETTINGS),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ApplicationSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ManageApplicationsActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 短信按钮：优先打开短信 App 的设置页；打不开就打开短信 App 主界面；仍打不开就不处理。
     * 不跳应用详情页。
     */
    public static void openSmsSetting(Activity activity) {
        Intent[] settingIntents = new Intent[]{
                // 通用/小米/部分国产 Android 短信设置
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessagingPreferenceActivity")),

                // Google Messages
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.ApplicationSettingsActivity")),

                // OPPO / OPlus / Realme / OnePlus 信息设置
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.coloros.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.oplus.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MessageSettings")),

                // vivo / iQOO 信息设置，已验证有效，保留在前面
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.bbk.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MessageSettings")),

                // Huawei / Honor 信息设置
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.huawei.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MessageSettings")),

                // Samsung
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.samsung.android.messaging.ui.view.setting.SettingsActivity"))
        };
        if (startFirstAvailable(activity, settingIntents, false)) {
            return;
        }

        // 打不开短信设置页，就打开系统默认短信 App 主界面。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String defaultSmsPkg = Telephony.Sms.getDefaultSmsPackage(activity);
            if (startPackageLaunch(activity, defaultSmsPkg)) {
                return;
            }
        }

        Intent[] mainIntents = new Intent[]{
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),

                // 通用 / 小米
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ComposeMessageActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.ConversationList")),

                // OPPO / OPlus / Realme / OnePlus
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MmsTabActivity")),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MmsTabActivity")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MmsTabActivity")),

                // Google / Samsung
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.apps.messaging"),
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.samsung.android.messaging")
        };
        if (startFirstAvailable(activity, mainIntents, false)) {
            return;
        }

        String[] packages = new String[]{
                "com.android.mms",
                "com.miui.mms",
                "com.google.android.apps.messaging",
                "com.coloros.mms",
                "com.oplus.mms",
                "com.heytap.mms",
                "com.bbk.mms",
                "com.vivo.mms",
                "com.huawei.mms",
                "com.hihonor.mms",
                "com.samsung.android.messaging"
        };
        for (String pkg : packages) {
            if (startPackageLaunch(activity, pkg)) {
                return;
            }
        }
    }

    private static boolean startPackageLaunch(Activity activity, String pkg) {
        if (pkg == null || pkg.trim().length() == 0) return false;
        try {
            PackageManager pm = activity.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(pkg);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(launchIntent);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static boolean startFirstAvailable(Activity activity, Intent[] intents, boolean showUnsupportedToast) {
        for (Intent intent : intents) {
            if (intent == null) continue;
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
                if (resolveInfo != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } catch (Exception ignored) {
            }
        }
        if (showUnsupportedToast) {
            Toast.makeText(activity, R.string.unsupport, Toast.LENGTH_SHORT).show();
        }
        return false;
    }

}
