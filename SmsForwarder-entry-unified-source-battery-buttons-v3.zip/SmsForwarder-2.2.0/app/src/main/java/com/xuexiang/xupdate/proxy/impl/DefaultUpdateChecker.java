package com.xuexiang.xupdate.proxy.impl;

public class DefaultUpdateChecker {
    public void onBeforeCheck() { }
    public void noNewVersion(Throwable throwable) { }
}
