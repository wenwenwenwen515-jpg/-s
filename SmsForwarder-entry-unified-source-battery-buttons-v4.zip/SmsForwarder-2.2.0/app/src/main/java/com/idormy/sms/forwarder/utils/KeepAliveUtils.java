package com.idormy.sms.forwarder.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.provider.Telephony;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.idormy.sms.forwarder.R;

public class KeepAliveUtils {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean isIgnoreBatteryOptimization(Activity activity) {
        PowerManager powerManager = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            return powerManager.isIgnoringBatteryOptimizations(activity.getPackageName());
        } else {
            return true;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void ignoreBatteryOptimization(Activity activity) {
        if (isIgnoreBatteryOptimization(activity)) {
            openAppBatterySetting(activity);
            return;
        }
        @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + activity.getPackageName()));
        ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo != null) {
            activity.startActivity(intent);
        } else {
            openAppBatterySetting(activity);
        }
    }

    /**
     * 打开手机系统电池/后台电量相关页面。
     * v4：把“省电模式/节电助手”放到最后，优先走设置里的电池首页。
     */
    public static void openAppBatterySetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();

        Intent[] commonBatteryHome = new Intent[]{
                new Intent(Settings.ACTION_BATTERY_SETTINGS),
                new Intent("android.settings.BATTERY_SETTINGS"),
                new Intent("android.intent.action.POWER_USAGE_SUMMARY"),
                new Intent("android.settings.POWER_USAGE_SUMMARY"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BatteryDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$PowerUsageSummaryActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.fuelgauge.PowerUsageSummary"))
        };

        // OPPO / OnePlus / Realme：已测试能进入电池首页，保留靠前。
        Intent[] oppoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerControlActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.power.PowerUsageSummaryActivity"))
        };

        // vivo / iQOO：不要优先跳“省电模式”，先尝试设置电池首页和 vivo 电池首页。
        Intent[] vivoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BatteryDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$PowerUsageSummaryActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.MainActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.powersaving", "com.iqoo.powersaving.PowerUsageActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.powersaving", "com.vivo.powersaving.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.powersaving", "com.vivo.powersaving.MainActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.AbeMainActivity"))
        };

        Intent[] xiaomiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.BatteryHistoryDetailActivity"))
        };

        Intent[] huaweiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerUsageActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.BatteryHistoryActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"))
        };

        Intent[] samsungBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        };

        if (manufacturer.contains("oppo") || manufacturer.contains("oneplus") || manufacturer.contains("realme") || manufacturer.contains("oplus")) {
            if (startFirstAvailable(activity, oppoBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
            if (startFirstAvailable(activity, vivoBattery, false)) return;
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            if (startFirstAvailable(activity, xiaomiBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            if (startFirstAvailable(activity, huaweiBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("samsung")) {
            if (startFirstAvailable(activity, samsungBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        }

        if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        if (startFirstAvailable(activity, oppoBattery, false)) return;
        if (startFirstAvailable(activity, xiaomiBattery, false)) return;
        if (startFirstAvailable(activity, vivoBattery, false)) return;
        if (startFirstAvailable(activity, huaweiBattery, false)) return;
        if (startFirstAvailable(activity, samsungBattery, false)) return;

        // 最后兜底才进入省电模式/系统设置，避免多数手机误进省电助手。
        Intent[] lastResort = new Intent[]{
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) : null,
                new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, lastResort, true);
    }

    /**
     * 尽量直接打开本应用权限管理页。
     * 厂商权限页不是 Android 统一公开接口，所以这里按常见系统多入口尝试。
     */
    public static void openAppPermissionSetting(Activity activity) {
        String pkg = activity.getPackageName();
        Intent[] intents = new Intent[]{
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.provider.extra.APP_PACKAGE", pkg)
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
                        .putExtra("packageName", pkg),
                new Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                        .setData(Uri.parse("package:" + pkg))
                        .putExtra("android.intent.extra.SHOW_FRAGMENT", "com.android.settings.applications.AppPermissionSettings"),

                // Xiaomi / MIUI / HyperOS
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg)
                        .putExtra("extra_package_uid", activity.getApplicationInfo().uid),

                // OPPO / OnePlus / ColorOS / OPlus
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.securitypermission", "com.oplus.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.safeguard.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.SingleAppActivity"))
                        .putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg),

                // Samsung
                new Intent().setComponent(new ComponentName("com.samsung.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg),
                new Intent().setComponent(new ComponentName("com.google.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 尽量打开厂商自启动设置页。
     * v4：vivo/小米保持原来能直达的逻辑；OPPO/华为直达失败后，跳“设置 -> 应用/应用和服务”总入口，
     * 不再跳“应用管理列表”。
     */
    public static void openAutoStartSetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();

        Intent[] vivoAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.SoftwareManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"))
        };

        Intent[] xiaomiAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartDetailManagementActivity"))
        };

        Intent[] oppoAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startupapp.StartupAppListActivity"))
        };

        Intent[] huaweiAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"))
        };

        // “设置 -> 应用/应用和服务”的总入口，避免进入具体“应用管理列表”。
        Intent[] oppoApplicationHome = new Intent[]{
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ApplicationsDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ApplicationSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.android.settings.Settings$ApplicationsDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.android.settings.Settings$ApplicationsDashboardActivity")),
                new Intent("android.settings.APPLICATION_SETTINGS")
        };

        Intent[] huaweiApplicationServiceHome = new Intent[]{
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ApplicationsDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$ApplicationSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.AppControlActivity")),
                new Intent("android.settings.APPLICATION_SETTINGS")
        };

        Intent[] otherAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity")),
                new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
                new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).putExtra("mobilemanager://function/entry/AutoStart", true),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity"))
        };

        if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            if (startFirstAvailable(activity, vivoAutoStart, false)) return;
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            if (startFirstAvailable(activity, xiaomiAutoStart, false)) return;
        } else if (manufacturer.contains("oppo") || manufacturer.contains("oneplus") || manufacturer.contains("realme") || manufacturer.contains("oplus")) {
            if (startFirstAvailable(activity, oppoAutoStart, false)) return;
            if (startFirstAvailable(activity, oppoApplicationHome, false)) return;
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            if (startFirstAvailable(activity, huaweiAutoStart, false)) return;
            if (startFirstAvailable(activity, huaweiApplicationServiceHome, false)) return;
        }

        if (startFirstAvailable(activity, oppoAutoStart, false)) return;
        if (startFirstAvailable(activity, xiaomiAutoStart, false)) return;
        if (startFirstAvailable(activity, vivoAutoStart, false)) return;
        if (startFirstAvailable(activity, huaweiAutoStart, false)) return;
        if (startFirstAvailable(activity, otherAutoStart, false)) return;
        if (startFirstAvailable(activity, oppoApplicationHome, false)) return;
        if (startFirstAvailable(activity, huaweiApplicationServiceHome, false)) return;

        startFirstAvailable(activity, new Intent[]{new Intent(Settings.ACTION_SETTINGS)}, false);
    }

    /**
     * 短信按钮：优先打开短信 App 设置页；打不开设置页就打开短信/信息 App 主界面；仍打不开就不处理。
     * v4 重点补 OPPO / 小米 / 华为 / 荣耀：加入 ACTION_VIEW sms: 和更多包名/Activity。
     */
    public static void openSmsSetting(Activity activity) {
        // vivo 已验证可以进入信息设置，放前面保留成功逻辑。
        Intent[] settingIntents = new Intent[]{
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.bbk.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MessageSettings")),

                // 通用 / 小米 / MIUI / HyperOS
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.xiaomi.mms", "com.android.mms.ui.MessageSettings")),

                // OPPO / OPlus / Realme / OnePlus
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.coloros.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.oplus.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.heytap.mms.ui.MessageSettings")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.huawei.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.huawei.mms.ui.MessageSettings")),

                // Google / Samsung
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.ApplicationSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.samsung.android.messaging.ui.view.setting.SettingsActivity"))
        };
        if (startFirstAvailable(activity, settingIntents, false)) return;

        // 打不开设置页，优先打开系统默认短信 App。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String defaultSmsPkg = Telephony.Sms.getDefaultSmsPackage(activity);
            if (startPackageLaunch(activity, defaultSmsPkg)) return;
            if (defaultSmsPkg != null && startFirstAvailable(activity, new Intent[]{
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(defaultSmsPkg),
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING).setPackage(defaultSmsPkg)
            }, false)) return;
        }

        // 这个通常能打开默认短信/信息 App，成功率比具体组件更高。
        Intent[] genericSmsIntents = new Intent[]{
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
                new Intent(Intent.ACTION_VIEW).setData(Uri.parse("sms:")),
                new Intent(Intent.ACTION_VIEW).setData(Uri.parse("smsto:")),
                new Intent(Intent.ACTION_SENDTO).setData(Uri.parse("smsto:"))
        };
        if (startFirstAvailable(activity, genericSmsIntents, false)) return;

        Intent[] mainIntents = new Intent[]{
                // 通用 / 小米
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ComposeMessageActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.xiaomi.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.android.messaging", "com.android.messaging.ui.conversationlist.ConversationListActivity")),

                // OPPO / OPlus / Realme / OnePlus
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.ConversationList")),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MmsTabActivity")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.ConversationList")),

                // Google / Samsung
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.apps.messaging"),
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.samsung.android.messaging")
        };
        if (startFirstAvailable(activity, mainIntents, false)) return;

        String[] packages = new String[]{
                "com.bbk.mms",
                "com.vivo.mms",
                "com.android.mms",
                "com.miui.mms",
                "com.xiaomi.mms",
                "com.android.messaging",
                "com.google.android.apps.messaging",
                "com.coloros.mms",
                "com.oplus.mms",
                "com.heytap.mms",
                "com.huawei.mms",
                "com.hihonor.mms",
                "com.samsung.android.messaging"
        };
        for (String pkg : packages) {
            if (startPackageLaunch(activity, pkg)) return;
        }
    }

    private static boolean startPackageLaunch(Activity activity, String pkg) {
        if (pkg == null || pkg.trim().length() == 0) return false;
        try {
            PackageManager pm = activity.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(pkg);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(launchIntent);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static boolean startFirstAvailable(Activity activity, Intent[] intents, boolean showUnsupportedToast) {
        for (Intent intent : intents) {
            if (intent == null) continue;
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
                if (resolveInfo != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } catch (Exception ignored) {
            }
        }
        if (showUnsupportedToast) {
            Toast.makeText(activity, R.string.unsupport, Toast.LENGTH_SHORT).show();
        }
        return false;
    }

}
