package com.idormy.sms.forwarder;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.idormy.sms.forwarder.adapter.LogAdapter;
import com.idormy.sms.forwarder.model.vo.LogVo;
import com.idormy.sms.forwarder.service.FrontService;
import com.idormy.sms.forwarder.utils.CommonUtil;
import com.idormy.sms.forwarder.utils.KeepAliveUtils;
import com.idormy.sms.forwarder.utils.LogUtil;
import com.idormy.sms.forwarder.utils.NetUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.SettingUtil;
import com.idormy.sms.forwarder.utils.SmsUtil;
import com.idormy.sms.forwarder.utils.TimeUtil;
import com.umeng.analytics.MobclickAgent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RefreshListView.IRefreshListener {

    private final String TAG = "MainActivity";
    // logVoList用于存储数据
    private List<LogVo> logVos = new ArrayList<>();
    private LogAdapter adapter;
    private RefreshListView listView;
    private Intent serviceIntent;
    private String currentType = "sms";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        LogUtil.init(this);
        Log.d(TAG, "onCreate");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initHomeSettings();

        //检查权限是否获取
        PackageManager pm = getPackageManager();
        CommonUtil.CheckPermission(pm, this);

        //获取SIM信息
        PhoneUtils.init(this);

        //短信&网络组件初始化
        SmsUtil.init(this);
        NetUtil.init(this);

        //前台服务
        try {
            serviceIntent = new Intent(MainActivity.this, FrontService.class);
            serviceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onCreate:", e);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");

        //是否关闭页面提示
        TextView help_tip = findViewById(R.id.help_tip);
        help_tip.setVisibility(MyApplication.showHelpTip ? View.VISIBLE : View.GONE);

        // 先拿到数据并放在适配器上
        initTLogs(); //初始化数据
        showList(logVos);

        //切换日志类别
        int typeCheckId = getTypeCheckId(currentType);
        final RadioGroup radioGroupTypeCheck = findViewById(R.id.radioGroupTypeCheck);
        radioGroupTypeCheck.check(typeCheckId);
        radioGroupTypeCheck.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            currentType = (String) rb.getTag();
            initTLogs();
            showList(logVos);
        });

        // 为ListView注册一个监听器，当用户点击了ListView中的任何一个子项时，就会回调onItemClick()方法
        // 在这个方法中可以通过position参数判断出用户点击的是那一个子项
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position <= 0) return;

            LogVo logVo = logVos.get(position - 1);
            logDetail(logVo);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position <= 0) return false;

            //定义AlertDialog.Builder对象，当长按列表项的时候弹出确认删除对话框
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle(R.string.delete_log_title);
            builder.setMessage(R.string.delete_log_tips);

            //添加AlertDialog.Builder对象的setPositiveButton()方法
            builder.setPositiveButton(R.string.confirm, (dialog, which) -> {
                Long id1 = logVos.get(position - 1).getId();
                Log.d(TAG, "id = " + id1);
                LogUtil.delLog(id1, null);
                initTLogs(); //初始化数据
                showList(logVos);
                Toast.makeText(getBaseContext(), R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            });

            //添加AlertDialog.Builder对象的setNegativeButton()方法
            builder.setNegativeButton(R.string.cancel, (dialog, which) -> {
            });

            builder.create().show();
            return true;
        });
    }

    private int getTypeCheckId(String currentType) {
        switch (currentType) {
            case "call":
                return R.id.btnTypeCall;
            case "app":
                return R.id.btnTypeApp;
            default:
                return R.id.btnTypeSms;
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);

        //第一次打开，未授权无法获取SIM信息，尝试在此重新获取
        if (MyApplication.SimInfoList.isEmpty()) {
            MyApplication.SimInfoList = PhoneUtils.getSimMultiInfo();
        }
        Log.d(TAG, "SimInfoList = " + MyApplication.SimInfoList.size());

        //省电优化设置为无限制
        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (!KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
                Toast.makeText(this, R.string.tips_battery_optimization, Toast.LENGTH_LONG).show();
            }
        }

        //开启读取通知栏权限
        if (SettingUtil.getSwitchEnableAppNotify() && !CommonUtil.isNotificationListenerServiceEnabled(this)) {
            CommonUtil.toggleNotificationListenerService(this);
            SettingUtil.switchEnableAppNotify(false);
            Toast.makeText(this, R.string.tips_notification_listener, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onResume:", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onDestroy:", e);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
        try {
            if (serviceIntent != null) startService(serviceIntent);
        } catch (Exception e) {
            Log.e(TAG, "onPause:", e);
        }
    }


    // 初始化首页右侧的通用设置面板
    private void initHomeSettings() {
        EditText et_add_extra_device_mark = findViewById(R.id.et_add_extra_device_mark);
        editAddExtraDeviceMark(et_add_extra_device_mark);

        EditText et_add_extra_sim1 = findViewById(R.id.et_add_extra_sim1);
        editAddExtraSim1(et_add_extra_sim1);

        EditText et_add_extra_sim2 = findViewById(R.id.et_add_extra_sim2);
        editAddExtraSim2(et_add_extra_sim2);

        EditText et_battery_level_alarm = findViewById(R.id.et_battery_level_alarm);
        editBatteryLevelAlarm(et_battery_level_alarm);

        editRetryDelayTime((EditText) findViewById(R.id.et_retry_delay_time1), 1);
        editRetryDelayTime((EditText) findViewById(R.id.et_retry_delay_time2), 2);
        editRetryDelayTime((EditText) findViewById(R.id.et_retry_delay_time3), 3);
        editRetryDelayTime((EditText) findViewById(R.id.et_retry_delay_time4), 4);
        editRetryDelayTime((EditText) findViewById(R.id.et_retry_delay_time5), 5);

        switchSmsTemplate((Switch) findViewById(R.id.switch_sms_template));
        switchEnableSms((Switch) findViewById(R.id.switch_enable_sms));
        switchEnablePhone((Switch) findViewById(R.id.switch_enable_phone));
        switchEnableAppNotify((Switch) findViewById(R.id.switch_enable_app_notify));
        switchExcludeFromRecents((Switch) findViewById(R.id.switch_exclude_from_recents));

        EditText textSmsTemplate = findViewById(R.id.text_sms_template);
        editSmsTemplate(textSmsTemplate);
    }

    //设置转发短信
    private void switchEnableSms(@SuppressLint("UseSwitchCompatOrMaterialCode") Switch switch_enable_sms) {
        switch_enable_sms.setChecked(SettingUtil.getSwitchEnableSms());
        switch_enable_sms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SettingUtil.switchEnableSms(isChecked);
            Log.d(TAG, "switchEnableSms:" + isChecked);
        });
    }

    //设置转发来电
    private void switchEnablePhone(@SuppressLint("UseSwitchCompatOrMaterialCode") Switch switch_enable_phone) {
        switch_enable_phone.setChecked(SettingUtil.getSwitchEnablePhone());
        switch_enable_phone.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SettingUtil.switchEnablePhone(isChecked);
            Log.d(TAG, "switchEnablePhone:" + isChecked);
        });
    }

    //设置转发APP通知
    private void switchEnableAppNotify(@SuppressLint("UseSwitchCompatOrMaterialCode") Switch switch_enable_app_notify) {
        switch_enable_app_notify.setChecked(SettingUtil.getSwitchEnableAppNotify());
        switch_enable_app_notify.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (!CommonUtil.isNotificationListenerServiceEnabled(this)) {
                    CommonUtil.openNotificationAccess(this);
                    Toast.makeText(this, "请先授予《短信转发器》通知使用权，否则无法转发APP通知，开启失败!", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    Toast.makeText(this, "通知服务已开启", Toast.LENGTH_LONG).show();
                    CommonUtil.toggleNotificationListenerService(this);
                }
            }
            SettingUtil.switchEnableAppNotify(isChecked);
            Log.d(TAG, "switchEnableAppNotify:" + isChecked);
        });
    }

    //不在最近任务列表中显示
    @SuppressLint("ObsoleteSdkInt")
    private void switchExcludeFromRecents(@SuppressLint("UseSwitchCompatOrMaterialCode") Switch switch_exclude_from_recents) {
        switch_exclude_from_recents.setChecked(SettingUtil.getExcludeFromRecents());
        switch_exclude_from_recents.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SettingUtil.switchExcludeFromRecents(isChecked);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ActivityManager am = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    List<ActivityManager.AppTask> appTasks = am.getAppTasks();
                    if (appTasks != null && !appTasks.isEmpty()) {
                        appTasks.get(0).setExcludeFromRecents(isChecked);
                    }
                }
            }
            Log.d(TAG, "onCheckedChanged:" + isChecked);
        });
    }

    //设置设备名称
    private void editAddExtraDeviceMark(final EditText et_add_extra_device_mark) {
        et_add_extra_device_mark.setText(SettingUtil.getAddExtraDeviceMark());
        et_add_extra_device_mark.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                SettingUtil.setAddExtraDeviceMark(et_add_extra_device_mark.getText().toString());
            }
        });
    }

    //设置SIM1备注
    private void editAddExtraSim1(final EditText et_add_extra_sim1) {
        et_add_extra_sim1.setText(SettingUtil.getAddExtraSim1());
        et_add_extra_sim1.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                SettingUtil.setAddExtraSim1(et_add_extra_sim1.getText().toString());
            }
        });
    }

    //设置SIM2备注
    private void editAddExtraSim2(final EditText et_add_extra_sim2) {
        et_add_extra_sim2.setText(SettingUtil.getAddExtraSim2());
        et_add_extra_sim2.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                SettingUtil.setAddExtraSim2(et_add_extra_sim2.getText().toString());
            }
        });
    }

    //设置低电量报警值
    private void editBatteryLevelAlarm(final EditText et_battery_level_alarm) {
        et_battery_level_alarm.setText(String.valueOf(SettingUtil.getBatteryLevelAlarm()));
        et_battery_level_alarm.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                String batteryLevel = et_battery_level_alarm.getText().toString();
                SettingUtil.setBatteryLevelAlarm(!batteryLevel.isEmpty() ? Integer.parseInt(batteryLevel) : 0);
            }
        });
    }

    //接口请求失败重试
    private void editRetryDelayTime(final EditText et_retry_delay_time, final int index) {
        et_retry_delay_time.setText(String.valueOf(SettingUtil.getRetryDelayTime(index)));
        et_retry_delay_time.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                String delayTime = et_retry_delay_time.getText().toString();
                SettingUtil.setRetryDelayTime(index, !delayTime.isEmpty() ? Integer.parseInt(delayTime) : 0);
            }
        });
    }

    //设置转发时启用自定义模版
    private void switchSmsTemplate(@SuppressLint("UseSwitchCompatOrMaterialCode") Switch switch_sms_template) {
        boolean isOn = SettingUtil.getSwitchSmsTemplate();
        switch_sms_template.setChecked(isOn);
        final LinearLayout layout_sms_template = findViewById(R.id.layout_sms_template);
        layout_sms_template.setVisibility(isOn ? View.VISIBLE : View.GONE);
        final EditText textSmsTemplate = findViewById(R.id.text_sms_template);
        switch_sms_template.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Log.d(TAG, "onCheckedChanged:" + isChecked);
            layout_sms_template.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            SettingUtil.switchSmsTemplate(isChecked);
            if (!isChecked) {
                textSmsTemplate.setText("{{来源号码}}\n{{短信内容}}\n{{卡槽信息}}\n{{接收时间}}\n{{设备名称}}");
            }
        });
    }

    //设置转发信息模版
    private void editSmsTemplate(final EditText textSmsTemplate) {
        textSmsTemplate.setText(SettingUtil.getSmsTemplate());
        textSmsTemplate.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                SettingUtil.setSmsTemplate(textSmsTemplate.getText().toString());
            }
        });
    }

    //插入标签
    @SuppressLint("NonConstantResourceId")
    public void toInsertLabel(View v) {
        EditText textSmsTemplate = findViewById(R.id.text_sms_template);
        textSmsTemplate.setFocusable(true);
        textSmsTemplate.requestFocus();
        switch (v.getId()) {
            case R.id.bt_insert_sender:
                textSmsTemplate.append("{{来源号码}}");
                return;
            case R.id.bt_insert_content:
                textSmsTemplate.append("{{短信内容}}");
                return;
            case R.id.bt_insert_extra:
                textSmsTemplate.append("{{卡槽信息}}");
                return;
            case R.id.bt_insert_time:
                textSmsTemplate.append("{{接收时间}}");
                return;
            case R.id.bt_insert_device_name:
                textSmsTemplate.append("{{设备名称}}");
                return;
            default:
        }
    }

    //恢复初始化配置
    public void initSetting(View view) {
        EditText et_add_extra_device_mark = findViewById(R.id.et_add_extra_device_mark);
        et_add_extra_device_mark.setText("");
        editAddExtraDeviceMark(et_add_extra_device_mark);

        EditText et_add_extra_sim1 = findViewById(R.id.et_add_extra_sim1);
        et_add_extra_sim1.setText("");
        editAddExtraSim1(et_add_extra_sim1);

        EditText et_add_extra_sim2 = findViewById(R.id.et_add_extra_sim2);
        et_add_extra_sim2.setText("");
        editAddExtraSim2(et_add_extra_sim2);

        Switch switch_sms_template = findViewById(R.id.switch_sms_template);
        switch_sms_template.setChecked(false);
        switchSmsTemplate(switch_sms_template);

        EditText textSmsTemplate = findViewById(R.id.text_sms_template);
        textSmsTemplate.setText("{{来源号码}}\n{{短信内容}}\n{{卡槽信息}}\n{{接收时间}}\n{{设备名称}}");
        editSmsTemplate(textSmsTemplate);
    }

    //电池优化设置
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void batterySetting(View view) {
        if (KeepAliveUtils.isIgnoreBatteryOptimization(this)) {
            Toast.makeText(this, R.string.isIgnored, Toast.LENGTH_SHORT).show();
        } else {
            KeepAliveUtils.ignoreBatteryOptimization(this);
        }
    }

    //请求通知使用权限
    public void requestNotificationPermission(View view) {
        if (!CommonUtil.isNotificationListenerServiceEnabled(this)) {
            CommonUtil.openNotificationAccess(this);
        } else {
            Toast.makeText(this, R.string.notification_listener_service_enabled, Toast.LENGTH_SHORT).show();
            CommonUtil.toggleNotificationListenerService(this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CommonUtil.NOTIFICATION_REQUEST_CODE) {
            if (CommonUtil.isNotificationListenerServiceEnabled(this)) {
                Toast.makeText(this, R.string.notification_listener_service_enabled, Toast.LENGTH_SHORT).show();
                CommonUtil.toggleNotificationListenerService(this);
                SettingUtil.switchEnableAppNotify(true);
            } else {
                Toast.makeText(this, R.string.notification_listener_service_disabled, Toast.LENGTH_SHORT).show();
                SettingUtil.switchEnableAppNotify(false);
            }
            Switch switch_enable_app_notify = findViewById(R.id.switch_enable_app_notify);
            if (switch_enable_app_notify != null) {
                switch_enable_app_notify.setChecked(SettingUtil.getSwitchEnableAppNotify());
            }
        }
    }

    // 权限判断相关
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // 初始化数据
    private void initTLogs() {
        logVos = LogUtil.getLog(null, null, currentType);
    }

    private void showList(List<LogVo> logVosN) {
        Log.d(TAG, "showList: " + logVosN);
        if (adapter == null) {
            // 将适配器上的数据传递给listView
            listView = findViewById(R.id.list_view_log);
            listView.setInterface(this);
            adapter = new LogAdapter(MainActivity.this, R.layout.item_log, logVosN);
            listView.setAdapter(adapter);
        } else {
            adapter.onDateChange(logVosN);
        }
    }

    @Override
    public void onRefresh() {
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            // TODO Auto-generated method stub
            //获取最新数据
            initTLogs();
            //通知界面显示
            showList(logVos);
            //通知listview 刷新数据完毕；
            listView.refreshComplete();
        }, 2000);
    }

    public void logDetail(LogVo logVo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.details);
        String simInfo = logVo.getSimInfo();
        if (simInfo != null) {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getSimInfo() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        } else {
            builder.setMessage(logVo.getFrom() + "\n\n" + logVo.getContent() + "\n\n" + logVo.getRule() + "\n\n" + TimeUtil.utc2Local(logVo.getTime()) + "\n\nResponse：" + logVo.getForwardResponse());
        }
        //删除
        builder.setNegativeButton(R.string.del, (dialog, which) -> {
            Long id = logVo.getId();
            Log.d(TAG, "id = " + id);
            LogUtil.delLog(id, null);
            initTLogs(); //初始化数据
            showList(logVos);
            Toast.makeText(MainActivity.this, R.string.delete_log_toast, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        builder.show();
    }

    public void toAppList() {
        Intent intent = new Intent(this, AppListActivity.class);
        startActivity(intent);
    }

    public void toClone() {
        Intent intent = new Intent(this, CloneActivity.class);
        startActivity(intent);
    }

    public void toSetting() {
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
    }

    public void toAbout() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    public void toHelp() {
        Uri uri = Uri.parse("https://gitee.com/pp/SmsForwarder/wikis/pages");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void toRuleSetting(View view) {
        Intent intent = new Intent(this, RuleActivity.class);
        startActivity(intent);
    }

    public void toSendSetting(View view) {
        Intent intent = new Intent(this, SenderActivity.class);
        startActivity(intent);
    }

    public void cleanLog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.clear_logs_tips)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    // TODO Auto-generated method stub
                    LogUtil.delLog(null, null);
                    initTLogs();
                    adapter.add(logVos);
                });
        builder.show();
    }

    //按返回键不退出回到桌面
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }

    //启用menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //menu点击事件
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.to_app_list:
                toAppList();
                return true;
            case R.id.to_clone:
                toClone();
                return true;
            case R.id.to_setting:
                toSetting();
                return true;
            case R.id.to_about:
                toAbout();
                return true;
            case R.id.to_help:
                toHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //设置menu图标显示
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        if (featureId == Window.FEATURE_ACTION_BAR && menu != null) {
            if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
                try {
                    Method m = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    m.setAccessible(true);
                    m.invoke(menu, true);
                } catch (NoSuchMethodException e) {
                    Log.e(TAG, "onMenuOpened", e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }

}
