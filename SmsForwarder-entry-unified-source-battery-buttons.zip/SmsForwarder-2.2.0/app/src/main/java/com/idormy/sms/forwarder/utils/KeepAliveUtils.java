package com.idormy.sms.forwarder.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.idormy.sms.forwarder.R;

public class KeepAliveUtils {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean isIgnoreBatteryOptimization(Activity activity) {
        PowerManager powerManager = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            return powerManager.isIgnoringBatteryOptimizations(activity.getPackageName());
        } else {
            return true;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void ignoreBatteryOptimization(Activity activity) {
        if (isIgnoreBatteryOptimization(activity)) {
            openAppBatterySetting(activity);
            return;
        }
        @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + activity.getPackageName()));
        ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo != null) {
            activity.startActivity(intent);
        } else {
            openAppBatterySetting(activity);
        }
    }

    /**
     * 打开和本应用相关的电池/后台权限设置。
     * 不同厂商没有统一入口，所以按成功率依次尝试：应用详情页、电池优化列表、省电设置、系统设置。
     */
    public static void openAppBatterySetting(Activity activity) {
        Intent[] intents = new Intent[]{
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName())),
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) : null,
                new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };

        for (Intent intent : intents) {
            if (intent == null) continue;
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
            if (resolveInfo != null) {
                activity.startActivity(intent);
                return;
            }
        }

        Toast.makeText(activity, R.string.unsupport, Toast.LENGTH_SHORT).show();
    }
    /**
     * 尽量直接打开本应用权限管理页。不同系统没有统一公开入口，先尝试常见权限页，失败则不处理。
     */
    public static void openAppPermissionSetting(Activity activity) {
        String pkg = activity.getPackageName();
        Intent[] intents = new Intent[]{
                new Intent("android.settings.APP_PERMISSION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", pkg),
                new Intent("android.settings.APPLICATION_DETAILS_SETTINGS").setData(Uri.parse("package:" + pkg)).putExtra("android.intent.extra.SHOW_FRAGMENT", "com.android.settings.applications.AppPermissionSettings"),
                new Intent("miui.intent.action.APP_PERM_EDITOR").putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR").setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity").putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR").setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity").putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppAllPermissionActivity")).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity")).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.safeguard.SoftPermissionDetailActivity")).putExtra("packagename", pkg),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity")).putExtra("packageName", pkg)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 尽量打开厂商自启动设置页；如果都不支持，则只打开系统设置；系统设置也打不开就不处理。
     * 不跳转应用详情页。
     */
    public static void openAutoStartSetting(Activity activity) {
        Intent[] intents = new Intent[]{
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
                new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity")),
                new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
                new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).putExtra("mobilemanager://function/entry/AutoStart", true),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 尽量打开短信相关设置页；失败则尝试系统默认应用页；仍失败就不处理。
     * 不跳转应用详情页。
     */
    public static void openSmsSetting(Activity activity) {
        Intent[] intents = new Intent[]{
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ? new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS) : null,
                new Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS"),
                new Intent("android.settings.SMS_DEFAULT_DIALOG"),
                new Intent("com.android.mms.ui.MessageSettings"),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.SettingsActivity"))
        };
        startFirstAvailable(activity, intents, false);
    }

    private static boolean startFirstAvailable(Activity activity, Intent[] intents, boolean showUnsupportedToast) {
        for (Intent intent : intents) {
            if (intent == null) continue;
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
                if (resolveInfo != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } catch (Exception ignored) {
            }
        }
        if (showUnsupportedToast) {
            Toast.makeText(activity, R.string.unsupport, Toast.LENGTH_SHORT).show();
        }
        return false;
    }

}
